namespace FitZoneGym.Forms
{
    partial class ShellForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>Designer generated: do not modify the contents of this method with the code editor.</summary>
        private void InitializeComponent()
        {
            this.rightPanel = new System.Windows.Forms.Panel();
            this.contentPanel = new System.Windows.Forms.Panel();
            this.headerPanel = new System.Windows.Forms.Panel();
            this.titleLabel = new System.Windows.Forms.Label();
            this.actionsFlow = new System.Windows.Forms.FlowLayoutPanel();
            this.userStrip = new System.Windows.Forms.Panel();
            this.whoLabel = new System.Windows.Forms.Label();
            this.sidebarPanel = new System.Windows.Forms.Panel();
            this.navFlow = new System.Windows.Forms.FlowLayoutPanel();
            this.logoutButton = new System.Windows.Forms.Button();
            this.logoLabel = new System.Windows.Forms.Label();
            this.rightPanel.SuspendLayout();
            this.contentPanel.SuspendLayout();
            this.headerPanel.SuspendLayout();
            this.actionsFlow.SuspendLayout();
            this.userStrip.SuspendLayout();
            this.sidebarPanel.SuspendLayout();
            this.navFlow.SuspendLayout();
            this.SuspendLayout();
            // 
            // rightPanel
            // 
            this.rightPanel.Name = "rightPanel";
            this.rightPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rightPanel.Controls.Add(this.contentPanel);
            this.rightPanel.Controls.Add(this.headerPanel);
            this.rightPanel.Controls.Add(this.userStrip);
            this.rightPanel.TabIndex = 0;
            // 
            // contentPanel
            // 
            this.contentPanel.Name = "contentPanel";
            this.contentPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.contentPanel.Padding = new System.Windows.Forms.Padding(16, 16, 16, 16);
            this.contentPanel.BackColor = System.Drawing.Color.FromArgb(243, 246, 251);
            this.contentPanel.TabIndex = 0;
            // 
            // headerPanel
            // 
            this.headerPanel.Name = "headerPanel";
            this.headerPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.headerPanel.Height = 56;
            this.headerPanel.BackColor = System.Drawing.Color.White;
            this.headerPanel.Padding = new System.Windows.Forms.Padding(18, 4, 18, 4);
            this.headerPanel.Controls.Add(this.titleLabel);
            this.headerPanel.Controls.Add(this.actionsFlow);
            this.headerPanel.TabIndex = 1;
            // 
            // titleLabel
            // 
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.titleLabel.AutoSize = false;
            this.titleLabel.Font = new System.Drawing.Font("Segoe UI", 15.0F, System.Drawing.FontStyle.Bold);
            this.titleLabel.ForeColor = System.Drawing.Color.FromArgb(15, 35, 66);
            this.titleLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.titleLabel.Text = "Title";
            this.titleLabel.TabIndex = 0;
            // 
            // actionsFlow
            // 
            this.actionsFlow.Name = "actionsFlow";
            this.actionsFlow.Dock = System.Windows.Forms.DockStyle.Right;
            this.actionsFlow.AutoSize = true;
            this.actionsFlow.WrapContents = false;
            this.actionsFlow.FlowDirection = System.Windows.Forms.FlowDirection.LeftToRight;
            this.actionsFlow.BackColor = System.Drawing.Color.White;
            this.actionsFlow.Padding = new System.Windows.Forms.Padding(0, 4, 0, 0);
            this.actionsFlow.TabIndex = 1;
            // 
            // userStrip
            // 
            this.userStrip.Name = "userStrip";
            this.userStrip.Dock = System.Windows.Forms.DockStyle.Top;
            this.userStrip.Height = 34;
            this.userStrip.BackColor = System.Drawing.Color.FromArgb(15, 35, 66);
            this.userStrip.Controls.Add(this.whoLabel);
            this.userStrip.TabIndex = 2;
            // 
            // whoLabel
            // 
            this.whoLabel.Name = "whoLabel";
            this.whoLabel.Dock = System.Windows.Forms.DockStyle.Right;
            this.whoLabel.AutoSize = false;
            this.whoLabel.Width = 560;
            this.whoLabel.ForeColor = System.Drawing.Color.White;
            this.whoLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.whoLabel.Padding = new System.Windows.Forms.Padding(0, 0, 14, 0);
            this.whoLabel.Text = "";
            this.whoLabel.TabIndex = 0;
            // 
            // sidebarPanel
            // 
            this.sidebarPanel.Name = "sidebarPanel";
            this.sidebarPanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.sidebarPanel.Width = 230;
            this.sidebarPanel.BackColor = System.Drawing.Color.FromArgb(15, 35, 66);
            this.sidebarPanel.Controls.Add(this.navFlow);
            this.sidebarPanel.Controls.Add(this.logoutButton);
            this.sidebarPanel.Controls.Add(this.logoLabel);
            this.sidebarPanel.TabIndex = 1;
            // 
            // navFlow
            // 
            this.navFlow.Name = "navFlow";
            this.navFlow.Dock = System.Windows.Forms.DockStyle.Fill;
            this.navFlow.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.navFlow.WrapContents = false;
            this.navFlow.AutoScroll = true;
            this.navFlow.BackColor = System.Drawing.Color.FromArgb(15, 35, 66);
            this.navFlow.Padding = new System.Windows.Forms.Padding(0, 6, 0, 0);
            this.navFlow.TabIndex = 0;
            // 
            // logoutButton
            // 
            this.logoutButton.Name = "logoutButton";
            this.logoutButton.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.logoutButton.Height = 46;
            this.logoutButton.Text = "   Logout";
            this.logoutButton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.logoutButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logoutButton.ForeColor = System.Drawing.Color.White;
            this.logoutButton.BackColor = System.Drawing.Color.FromArgb(140, 30, 40);
            this.logoutButton.Font = new System.Drawing.Font("Segoe UI", 10.0F, System.Drawing.FontStyle.Bold);
            this.logoutButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.logoutButton.UseVisualStyleBackColor = false;
            this.logoutButton.TabIndex = 1;
            this.logoutButton.Click += new System.EventHandler(this.logoutButton_Click);
            // 
            // logoLabel
            // 
            this.logoLabel.Name = "logoLabel";
            this.logoLabel.Dock = System.Windows.Forms.DockStyle.Top;
            this.logoLabel.Height = 64;
            this.logoLabel.Text = "FITZONE GYM";
            this.logoLabel.ForeColor = System.Drawing.Color.White;
            this.logoLabel.Font = new System.Drawing.Font("Segoe UI", 15.0F, System.Drawing.FontStyle.Bold);
            this.logoLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.logoLabel.BackColor = System.Drawing.Color.FromArgb(15, 35, 66);
            this.logoLabel.TabIndex = 2;
            // 
            // ShellForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(1280, 760);
            this.MinimumSize = new System.Drawing.Size(1150, 700);
            this.BackColor = System.Drawing.Color.FromArgb(243, 246, 251);
            this.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.Text = "FITZONE GYM";
            this.Controls.Add(this.rightPanel);
            this.Controls.Add(this.sidebarPanel);
            this.navFlow.ResumeLayout(false);
            this.navFlow.PerformLayout();
            this.sidebarPanel.ResumeLayout(false);
            this.sidebarPanel.PerformLayout();
            this.userStrip.ResumeLayout(false);
            this.userStrip.PerformLayout();
            this.actionsFlow.ResumeLayout(false);
            this.actionsFlow.PerformLayout();
            this.headerPanel.ResumeLayout(false);
            this.headerPanel.PerformLayout();
            this.contentPanel.ResumeLayout(false);
            this.contentPanel.PerformLayout();
            this.rightPanel.ResumeLayout(false);
            this.rightPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Panel rightPanel;
        protected System.Windows.Forms.Panel contentPanel;
        private System.Windows.Forms.Panel headerPanel;
        protected System.Windows.Forms.Label titleLabel;
        protected System.Windows.Forms.FlowLayoutPanel actionsFlow;
        private System.Windows.Forms.Panel userStrip;
        private System.Windows.Forms.Label whoLabel;
        private System.Windows.Forms.Panel sidebarPanel;
        protected System.Windows.Forms.FlowLayoutPanel navFlow;
        private System.Windows.Forms.Button logoutButton;
        private System.Windows.Forms.Label logoLabel;
    }
}
